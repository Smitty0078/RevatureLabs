package fixtures;

//Intractable interface... just now realized i've been spelling it wrong this whole time...
//ooooops...
public interface Interactable {

	public void interact();
	
}
